from django.shortcuts import render
import mysql.connector as sql
from mysql.connector import Error
import os
import csv
import numpy as np
import base64
from django.http import HttpResponse

def statistical_analysis_view(request, file_name):
    # Decode the file name
    decoded_file = base64.urlsafe_b64decode(file_name).decode()
    base_file_name = os.path.basename(decoded_file)  # Extract the file name
    details = []

    try:
        # Connect to the MySQL database
        connection = sql.connect(host="localhost", user="root", password="VARDHAN", database='login')
        if connection.is_connected():
            cursor = connection.cursor(dictionary=True)

            # Fetch details from info3 based on the file name or NULL (assuming these are defaults)
            cursor.execute("SELECT DISTINCT column_name FROM info3 WHERE file_name=%s OR file_name IS NULL", (decoded_file,))
            file_details = cursor.fetchall()
            print(f"File details fetched: {file_details}")

            # Ensure all result sets are processed
            while cursor.nextset():
                pass

            # Construct the file path and read the CSV file
            file_path = os.path.join("C:/Users/Unical-012/Downloads/", decoded_file)
            if os.path.exists(file_path):
                with open(file_path, 'r') as csvfile:
                    reader = csv.reader(csvfile, delimiter=',')
                    column_names = next(reader)  # Assuming the first row contains column names

                    data = list(reader)  # Read the remaining rows into a list

                    processed_columns = set()  # Track processed columns

                    for detail in file_details:
                        col_name = detail['column_name']
                        if col_name in column_names and col_name not in processed_columns:
                            col_index = column_names.index(col_name)
                            col_data = [float(row[col_index]) for row in data if row[col_index].replace('.', '', 1).isdigit()]
                            
                            if col_data:
                                col_data = np.array(col_data)
                                max_value = np.max(col_data)
                                min_value = np.min(col_data)
                                avg_value = np.mean(col_data)
                                std_deviation = np.std(col_data)
                                mean_deviation = np.mean(np.abs(col_data - avg_value))

                                details.append({
                                    'file_name': base_file_name,  # Use the extracted file name
                                    'parameter': col_name,
                                    'max_value': max_value,
                                    'min_value': min_value,
                                    'avg_value': avg_value,
                                    'std_deviation': std_deviation,
                                    'mean_deviation': mean_deviation,
                                })
                            
                            # Mark the column as processed
                            processed_columns.add(col_name)
                        else:
                            print(f"Column {col_name} not found in the file or already processed")
    except Error as e:
        return HttpResponse(f"Error while connecting to MySQL: {e}")
    finally:
        if connection.is_connected():
            cursor.close()
            connection.close()
            print("MySQL connection is closed")

    print(f"Context details: {{'details': {details}}}")
    context = {
        'details': details,
    }

    return render(request, 'statistical.html', context)
