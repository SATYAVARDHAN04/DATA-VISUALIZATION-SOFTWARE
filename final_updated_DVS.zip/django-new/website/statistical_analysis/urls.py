# statistical/urls.py
from django.urls import path
from .views import statistical_analysis_view

urlpatterns = [
    path('<str:file_name>/', statistical_analysis_view, name='statistical_analysis'),
]
