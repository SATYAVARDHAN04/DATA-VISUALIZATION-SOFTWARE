from django.shortcuts import render, redirect
import mysql.connector as sql
from mysql.connector import Error
import os
import csv

def maintask_view(request, file_name=None):
    filenames = []
    details = []
    selected_file = file_name
    try:
        connection = sql.connect(host="localhost", user="root", password="VARDHAN", database='login')
        if connection.is_connected():
            cursor = connection.cursor()
            cursor.execute("SELECT DISTINCT files FROM info2 WHERE created_time >= NOW() - INTERVAL 1 DAY")
            files = cursor.fetchall()
            filenames = [file[0] for file in files]

            if request.method == 'POST':
                if 'file_name' in request.POST:
                    selected_file = request.POST.get('file_name')
                    if selected_file:
                        cursor.execute("SELECT * FROM info2 WHERE files=%s", (selected_file,))
                        file_details = cursor.fetchone()

                        while cursor.nextset():
                            pass

                        file_path = os.path.join("C:/Users/Unical-012/Downloads/", selected_file)

                        if os.path.exists(file_path):
                            with open(file_path, 'r') as csvfile:
                                reader = csv.reader(csvfile, delimiter='\t')
                                column_names = next(reader)

                                for i, col in enumerate(column_names):
                                    a = col.split(",")
                                    for j in a:
                                        details.append({
                                            'file_name': selected_file,
                                            'column_number': i + 1,
                                            'column_name': j,
                                            'time_param': request.POST.get(f'time_param_{i}', '0'),
                                            'parameter_type': request.POST.get(f'parameter_type_{i}', 'continuous'),
                                            'range_from': request.POST.get(f'range_from_{i}', '0'),
                                            'range_to': request.POST.get(f'range_to_{i}', '100'),
                                        })

                if 'proceed' in request.POST:
                    details = []
                    row_count = int(request.POST.get('row_count', 0))
                    for i in range(row_count):
                        detail = {
                            'file_name': selected_file,
                            'column_number': int(request.POST.get(f'column_number_{i}', '0')),
                            'column_name': request.POST.get(f'column_name_{i}', ''),
                            'time_param': int(request.POST.get(f'time_param_{i}', '0')),
                            'parameter_type': request.POST.get(f'parameter_type_{i}', 'continuous'),
                            'range_from': int(request.POST.get(f'range_from_{i}', '0')),
                            'range_to': int(request.POST.get(f'range_to_{i}', '100')),
                        }
                        details.append(detail)

                    for detail in details:
                        cursor.execute(
                            "INSERT INTO info3 (file_name, column_number, column_name, time_param, parameter_type, range_from, range_to) VALUES (%s, %s, %s, %s, %s, %s, %s)",
                            (selected_file, detail['column_number'], detail['column_name'], detail['time_param'], detail['parameter_type'], detail['range_from'], detail['range_to'])
                        )
                    connection.commit()
                    return redirect('http://127.0.0.1:8000/pickingtable/')

    except Error as e:
        print(f"Error while connecting to MySQL: {e}")
    finally:
        if connection.is_connected():
            cursor.close()
            connection.close()

    context = {
        'filenames': filenames,
        'details': details,
        'selected_file': selected_file,
    }

    return render(request, 'next.html', context)
