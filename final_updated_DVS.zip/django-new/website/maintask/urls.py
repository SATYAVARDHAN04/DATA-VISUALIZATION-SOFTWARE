from django.urls import path
from . import views
from pickingtable.views import pictable_view  # Import the view from pickingtable

urlpatterns = [
    path('', views.maintask_view, name='maintask'),
    path('<str:file_name>/', views.maintask_view, name='maintask_with_file'),
    path('pictable/', pictable_view, name='pictable'),
]
