# urls.py
from django.urls import path
from .views import report_generation_view

urlpatterns = [
    # Other URL patterns
    path('report-generation/<str:file_name>/', report_generation_view, name='report_generation'),
]
