# signup/views.py
from django.shortcuts import render
import mysql.connector as sql
from mysql.connector import Error

def signaction(request):
    if request.method == "POST":
        try:
            # Connect to the database
            connection = sql.connect(host="localhost", user="root", passwd="VARDHAN", database='login')
            if connection.is_connected():
                cursor = connection.cursor()

                # Get form data
                data = request.POST
                name = data.get('name')
                gender = data.get('gender')
                email = data.get('email')
                password = data.get('password')

                print(name)

                # Use parameterized query to prevent SQL injection
                query = "INSERT INTO user (name, gender, email, password) VALUES (%s, %s, %s, %s)"
                cursor.execute(query, (name, gender, email, password))
                
                # Commit the transaction
                connection.commit()
                cursor.close()
                connection.close()
                
                print("Record inserted successfully into user table")

        except Error as e:
            print(f"Error while connecting to MySQL: {e}")
        finally:
            if connection.is_connected():
                cursor.close()
                connection.close()
                print("MySQL connection is closed")

    return render(request, 'signup_page.html')
