from django.shortcuts import render
import mysql.connector as sql
from mysql.connector import Error
import os
import csv
import matplotlib.pyplot as plt
import base64
from django.http import HttpResponse
from io import BytesIO

def visual_analysis_view(request, file_name):
    # Decode the file name
    decoded_file = base64.urlsafe_b64decode(file_name).decode()
    details = []
    columns = []

    try:
        # Connect to the MySQL database
        connection = sql.connect(host="localhost", user="root", password="VARDHAN", database='login')
        if connection.is_connected():
            cursor = connection.cursor()

            # Fetch details from the database
            cursor.execute("SELECT * FROM info2 WHERE files=%s", (decoded_file,))
            file_details = cursor.fetchone()

            # Ensure all result sets are processed
            while cursor.nextset():
                pass

            # Construct the file path and read the CSV file
            file_path = os.path.join("C:/Users/Unical-012/Downloads/", decoded_file)
            if os.path.exists(file_path):
                with open(file_path, 'r') as csvfile:
                    reader = csv.reader(csvfile, delimiter=',')
                    columns = next(reader)  # Assuming the first row contains column names

                    data = []
                    for row in reader:
                        data.append(row)

    except Error as e:
        return HttpResponse(f"Error while connecting to MySQL: {e}")
    finally:
        if connection.is_connected():
            cursor.close()
            connection.close()
            print("MySQL connection is closed")

    if request.method == 'POST':
        graph_type = request.POST['graphType']
        x_label = request.POST['xLabel']
        y_label = request.POST['yLabel']

        x_index = columns.index(x_label)
        y_index = columns.index(y_label)

        x_data = [float(row[x_index]) for row in data]
        y_data = [float(row[y_index]) for row in data]

        plt.figure()
        if graph_type == 'Bar Graph':
            plt.bar(x_data, y_data)
        elif graph_type == 'Line Graph':
            plt.plot(x_data, y_data)
        elif graph_type == 'Pie Chart':
            plt.pie(y_data, labels=x_data, autopct='%1.1f%%')

        plt.xlabel(x_label)
        plt.ylabel(y_label)
        plt.title(graph_type)

        buffer = BytesIO()
        plt.savefig(buffer, format='png')
        buffer.seek(0)
        response = HttpResponse(buffer, content_type='image/png')
        return response

    context = {
        'details': details,
        'columns': columns,
    }

    return render(request, 'visualanalysis.html', context)
