from django.apps import AppConfig


class VisualAnalysisConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'visual_analysis'
