from django.urls import path
from . import views

urlpatterns = [
    path('visual_analysis/<str:file_name>/', views.visual_analysis_view, name='visual_analysis'),
]
