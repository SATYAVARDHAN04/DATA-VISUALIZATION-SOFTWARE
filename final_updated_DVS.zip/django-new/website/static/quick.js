document.getElementById('back-button').addEventListener('click', function() {
    // Navigate back to the previous page or home page
    window.history.back();
});

// Function to increase font size
function increaseFontSize() {
    document.getElementById('analyze-table').style.fontSize = 'larger';
}

// Function to decrease font size
function decreaseFontSize() {
    document.getElementById('analyze-table').style.fontSize = 'smaller';
}
