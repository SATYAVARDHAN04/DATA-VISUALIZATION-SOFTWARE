document.addEventListener("DOMContentLoaded", function() {
    const backButton = document.getElementById('back-button');

    backButton.addEventListener('click', function() {
        window.history.back(); // Go back to the previous page
    });

    const showTableButton = document.getElementById('showTableButton');
    showTableButton.addEventListener('click', showTable);

    function showTable() {
        const timeParam = document.getElementById('time-param').value;
        const discreteParam = document.getElementById('discrete-param').value;

        fetch(`/state_transition/data/?time_param=${encodeURIComponent(timeParam)}&discrete_param=${encodeURIComponent(discreteParam)}`)
            .then(response => {
                if (!response.ok) {
                    throw new Error('Network response was not ok');
                }
                return response.json();
            })
            .then(data => {
                const tableBody = document.getElementById('table-body');
                tableBody.innerHTML = '';

                if (data.length === 0) {
                    document.getElementById('no-data-message').style.display = 'block';
                } else {
                    document.getElementById('no-data-message').style.display = 'none';

                    data.forEach((item, index) => {
                        const row = `
                            <tr>
                                <td>${index + 1}</td>
                                <td>${item.time_range}</td>
                                <td>${item.discrete_value}</td>
                            </tr>
                        `;
                        tableBody.innerHTML += row;
                    });
                }
            })
            .catch(error => {
                console.error('Error fetching data:', error);
                document.getElementById('no-data-message').style.display = 'block';
                document.getElementById('no-data-message').textContent = 'Error fetching data. Please try again.';
            });
    }
});
