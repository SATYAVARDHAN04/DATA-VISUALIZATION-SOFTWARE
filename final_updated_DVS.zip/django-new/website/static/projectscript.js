let addedFiles = [];

document.getElementById('add-file-button').addEventListener('click', function() {
    const fileInput = document.getElementById('project-files');
    const files = fileInput.files;

    if (files.length > 0) {
        for (let i = 0; i < files.length; i++) {
            const file = files[i];
            // Check if file is already added
            if (!addedFiles.includes(file.name)) {
                addedFiles.push(file.name);
                addFileToTable(file, document.getElementById('file-table-body').rows.length + 1);
            }
        }
        // Clear the file input for new selections without resetting it
        fileInput.value = '';
    } else {
        alert('No files selected to add.');
    }
});

document.getElementById('project-form').addEventListener('submit', function(event) {
    event.preventDefault();
    alert('Proceeding with form submission');
    this.submit();  // Submit the form after showing the alert
});

document.getElementById('import-button').addEventListener('click', function() {
    alert('Import functionality not implemented yet.');
});

document.getElementById('back-button').addEventListener('click', function() {
    window.history.back();
});

function addFileToTable(file, sno) {
    const fileTableBody = document.getElementById('file-table-body');
    const row = document.createElement('tr');
    const snoCell = document.createElement('td');
    const fileNameCell = document.createElement('td');
    snoCell.textContent = sno;
    fileNameCell.textContent = file.name;
    row.appendChild(snoCell);
    row.appendChild(fileNameCell);
    fileTableBody.appendChild(row);
}
