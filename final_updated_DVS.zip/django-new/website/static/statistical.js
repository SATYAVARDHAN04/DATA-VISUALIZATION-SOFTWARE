document.getElementById('back-button').addEventListener('click', function() {
    // Add your back button functionality here
    alert('Back button clicked');
});

// Function to increase font size
function increaseFontSize() {
    document.getElementById('analyze-table').style.fontSize = 'larger';
}

// Function to decrease font size
function decreaseFontSize() {
    document.getElementById('analyze-table').style.fontSize = 'smaller';
}

document.getElementById('show-selected').addEventListener('click', function() {
    // Fetch selected options and display in the table
    let tableBody = document.querySelector('#analyze-table tbody');
    tableBody.innerHTML = ''; // Clear existing rows

    let selectedFile = document.getElementById('file-select').value;
    let options = document.querySelectorAll('.options-selector input[type="checkbox"]:checked');

    options.forEach(option => {
        let newRow = tableBody.insertRow();
        newRow.innerHTML = `
            <td>${selectedFile}</td>
            <td>${option.value}</td>
            <td>-</td>
            <td>-</td>
            <td>-</td>
            <td>-</td>
            <td>-</td>
        `;
    });
});

document.getElementById('export-excel').addEventListener('click', function() {
    exportTableToExcel('analyze-table', 'statistical_analyze');
});

document.getElementById('export-pdf').addEventListener('click', function() {
    exportTableToPDF('analyze-table', 'Statistical Analyze');
});

function exportTableToExcel(tableID, filename = ''){
    let downloadLink;
    const dataType = 'application/vnd.ms-excel';
    const tableSelect = document.getElementById(tableID);
    const tableHTML = tableSelect.outerHTML.replace(/ /g, '%20');
    
    filename = filename?filename+'.xls':'excel_data.xls';
    
    downloadLink = document.createElement("a");
    document.body.appendChild(downloadLink);
    
    if(navigator.msSaveOrOpenBlob){
        const blob = new Blob(['\ufeff', tableHTML], { type: dataType });
        navigator.msSaveOrOpenBlob( blob, filename);
    } else {
        downloadLink.href = 'data:' + dataType + ', ' + tableHTML;
        downloadLink.download = filename;
        downloadLink.click();
    }
}

function exportTableToPDF(tableID, title){
    const doc = new jsPDF('l', 'pt', 'a4');
    const table = document.getElementById(tableID);
    const res = doc.autoTableHtmlToJson(table);
    doc.text(title, 40, 40);
    doc.autoTable(res.columns, res.data, { startY: 60 });
    doc.save(title + '.pdf');
}
