document.getElementById('back-button').addEventListener('click', function() {
    window.history.back();
});

document.getElementById('proceed-button').addEventListener('click', function() {
    alert('Proceeding with the form submission');
});

document.getElementById('details-form').onsubmit = function() {
    var rowCount = document.getElementById('file-table-body').rows.length;
    var rowCountInput = document.createElement('input');
    rowCountInput.type = 'hidden';
    rowCountInput.name = 'row_count';
    rowCountInput.value = rowCount;
    this.appendChild(rowCountInput);
};
