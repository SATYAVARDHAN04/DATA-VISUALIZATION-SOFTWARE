// document.querySelector('form').addEventListener('submit', function(event) {
//     event.preventDefault();
//     const username = document.querySelector('#username').value;
//     const password = document.querySelector('#password').value;
//     if (username === '' || password === '') {
//         alert('Please fill in all fields');
//     } else {
//         alert(`Username: ${username}\nPassword: ${password}`);
//     }
// });


// document.addEventListener('DOMContentLoaded', function() {
//     console.log("sfgh")
//     document.querySelector('.login-form').addEventListener('submit', function(event) {
//         event.preventDefault();
//         alert("gwsadgja");
//         console.log("sfgh")
//         const username = document.querySelector('#username').value;
//         const password = document.querySelector('#password').value;
//         if (username === '' || password === '') {
//             alert('Please fill in all fields');
//         } else {
//             alert(`Username: ${username}\nPassword: ${password}`);
//         }
//     });
// });

document.addEventListener('DOMContentLoaded', function() {
    const form = document.querySelector('.login-form');
    if (form) {
        form.addEventListener('submit', function(event) {
            const emailField = document.getElementById('email');
            const passwordField = document.getElementById('password');

            if (!emailField || !passwordField) {
                console.error('Email or Password field not found.');
                event.preventDefault();
                return;
            }

            // Optionally perform additional validation here
            // If validation fails, prevent the form submission
            // For example:
            const email = emailField.value.trim();
            const password = passwordField.value.trim();
            
            if (email === '' || password === '') {
                console.error('Email and Password are required.');
                event.preventDefault();
                return;
            }
        });
    } else {
        console.error('Login form not found.');
    }
});
