document.querySelector('form').addEventListener('submit', function(event) {
    const name = document.querySelector('#name').value;
    const email = document.querySelector('#email').value;
    const password = document.querySelector('#password').value;
    const gender = document.querySelector('#gender').value;

    if (name === '' || email === '' || password === '' || gender === '') {
        alert('Please fill in all fields');
        event.preventDefault(); // Prevent form submission if validation fails
    } else {
        // Optional: Show the alert for debugging purposes
        alert(`Name: ${name}\nEmail: ${email}\nPassword: ${password}\nGender: ${gender}`);

        // Simulate crackers effect
        simulateCrackers();

        // Form will be submitted if validation passes
    }
});

function simulateCrackers() {
    const crackersContainer = document.createElement('div');
    crackersContainer.className = 'crackers-container';
    document.body.appendChild(crackersContainer);

    // Create multiple cracker elements
    for (let i = 0; i < 20; i++) {
        const cracker = document.createElement('div');
        cracker.className = 'cracker';
        crackersContainer.appendChild(cracker);
    }

    // Remove crackers after animation completes
    setTimeout(() => {
        crackersContainer.remove();
    }, 3000); // Adjust duration as needed
}
