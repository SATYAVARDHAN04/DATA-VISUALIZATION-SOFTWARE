document.getElementById('addGraph').addEventListener('click', addGraph);
document.getElementById('deleteGraph').addEventListener('click', deleteGraph);
document.getElementById('deletePlot').addEventListener('click', deletePlot);

function addGraph() {
    const graphType = document.getElementById('graphType').value;
    const xLabel = document.getElementById('xLabel').value;
    const yLabel = document.getElementById('yLabel').value;

    if (graphType && xLabel && yLabel) {
        const table = document.getElementById('graphTable').getElementsByTagName('tbody')[0];
        const newRow = table.insertRow();

        const cell0 = newRow.insertCell(0);
        const cell1 = newRow.insertCell(1);
        const cell2 = newRow.insertCell(2);
        const cell3 = newRow.insertCell(3);

        cell0.innerHTML = table.rows.length + 1;
        cell1.innerHTML = graphType;
        cell2.innerHTML = xLabel;
        cell3.innerHTML = yLabel;

        // Also add to plot details
        const plotTable = document.getElementById('plotTable').getElementsByTagName('tbody')[0];
        const newPlotRow = plotTable.insertRow();

        const plotCell0 = newPlotRow.insertCell(0);
        const plotCell1 = newPlotRow.insertCell(1);
        const plotCell2 = newPlotRow.insertCell(2);

        plotCell0.innerHTML = '<button>Edit</button>';
        plotCell1.innerHTML = xLabel;
        plotCell2.innerHTML = yLabel;
    }
}

function deleteGraph() {
    const table = document.getElementById('graphTable').getElementsByTagName('tbody')[0];
    if (table.rows.length > 0) {
        table.deleteRow(table.rows.length - 1);
    }
}

function deletePlot() {
    const table = document.getElementById('plotTable').getElementsByTagName('tbody')[0];
    if (table.rows.length > 0) {
        table.deleteRow(table.rows.length - 1);
    }
}
