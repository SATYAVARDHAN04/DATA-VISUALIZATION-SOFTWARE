# login/views.py
from django.shortcuts import render, redirect
import mysql.connector as sql
from mysql.connector import Error

def loginaction(request):
    if request.method == "POST":
        try:
            # Connect to the database
            connection = sql.connect(host="localhost", user="root", password="VARDHAN", database='login')
            if connection.is_connected():
                cursor = connection.cursor()

                # Get form data
                email = request.POST.get('email')
                password = request.POST.get('password')

                # Use parameterized query to prevent SQL injection
                query = "SELECT * FROM user WHERE email=%s AND password=%s"
                cursor.execute(query, (email, password))
                
                result = cursor.fetchone()

                if result:
                    print("Login successful")
                    return render(request, "project.html")
                else:
                    print("Login failed: Invalid credentials")
                    return render(request, 'error.html')

        except Error as e:
            print(f"Error while connecting to MySQL: {e}")
        finally:
                print("MySQL connection is closed")

    return render(request, 'login_page.html')
