from django.shortcuts import render
import mysql.connector as sql
from mysql.connector import Error
import base64

def get_last_inserted_file():
    try:
        connection = sql.connect(
            host="localhost",
            user="root",
            password="VARDHAN",
            database='login'
        )
        if connection.is_connected():
            cursor = connection.cursor()
            cursor.execute("""
                SELECT files 
                FROM info2 
                ORDER BY created_at DESC 
                LIMIT 1
            """)
            row = cursor.fetchone()
            if row:
                return f"C:/Users/Unical-012/Downloads/{row[0]}"
            return None
    except Error as e:
        print(f"Error fetching the last inserted file: {e}")
        return None
    finally:
        if connection.is_connected():
            cursor.close()
            connection.close()

def pictable_view(request):
    # Fetch the last inserted file from the database
    last_file_name = get_last_inserted_file()

    if not last_file_name:
        # Render the error page if the file is not found
        return render(request, 'error.html', {'message': 'No file found in the database.'})

    # Encode the file path
    encoded_file = base64.urlsafe_b64encode(last_file_name.encode()).decode()

    context = {
        'selected_file': encoded_file,
    }

    return render(request, 'pictable.html', context)
