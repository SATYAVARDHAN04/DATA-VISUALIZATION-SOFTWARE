from django.shortcuts import render, redirect
import mysql.connector as sql
from mysql.connector import Error
from datetime import datetime

def selectionaction(request):
    if request.method == "POST":
        project_name = request.POST.get('project-name')
        project_description = request.POST.get('project-description')
        project_files = request.FILES.getlist('project-files')
        project_manager = request.POST.get('project-manager')

        try:
            connection = sql.connect(host="localhost", user="root", password="VARDHAN", database='login')
            if connection.is_connected():
                cursor = connection.cursor()
                for project_file in project_files:
                    file_name = project_file.name
                    query = "INSERT INTO info2 (project_name, project_description, project_manager, files, created_time) VALUES (%s, %s, %s, %s, %s)"
                    cursor.execute(query, (project_name, project_description, project_manager, file_name, datetime.now()))
                connection.commit()

        except Error as e:
            print(f"Error while connecting to MySQL: {e}")
        finally:
            if connection.is_connected():
                cursor.close()
                connection.close()
        
        return redirect('next')

    return render(request, 'project.html')

def next_view(request):
    filenames = []
    try:
        connection = sql.connect(host="localhost", user="root", password="VARDHAN", database='login')
        if connection.is_connected():
            cursor = connection.cursor()
            # Select files ordered by created_time in descending order and limit to the most recent file
            query = "SELECT files FROM info2 ORDER BY created_time DESC LIMIT 1"
            cursor.execute(query)
            filenames = [row[0] for row in cursor.fetchall()]
    except Error as e:
        print(f"Error while connecting to MySQL: {e}")
    finally:
        if connection.is_connected():
            cursor.close()
            connection.close()

    if request.method == "POST":
        selected_file = request.POST.get('file_name')
        if selected_file:
            return redirect('maintask_with_file', file_name=selected_file)  # Use the correct URL pattern name

    return render(request, 'next.html', {'filenames': filenames})