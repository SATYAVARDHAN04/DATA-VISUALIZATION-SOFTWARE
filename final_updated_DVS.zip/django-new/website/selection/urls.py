from django.urls import path
from . import views

urlpatterns = [
    path('selectionaction/', views.selectionaction, name='selectionaction'),
    path('next/', views.next_view, name='next'),
]
