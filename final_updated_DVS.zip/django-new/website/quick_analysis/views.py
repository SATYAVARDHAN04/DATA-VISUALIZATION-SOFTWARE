from django.shortcuts import render
import mysql.connector as sql
from mysql.connector import Error
import os
import csv
import numpy as np
import base64
from django.http import HttpResponse

def quick_analysis_view(request, file_name):
    # Decode the file name
    decoded_file = base64.urlsafe_b64decode(file_name).decode()
    base_file_name = os.path.basename(decoded_file)  # Extract the file name
    details = []

    try:
        # Connect to the MySQL database
        connection = sql.connect(host="localhost", user="root", password="VARDHAN", database='login')
        if connection.is_connected():
            cursor = connection.cursor()

            # Fetch details from the database (this step can be omitted if not needed)
            cursor.execute("SELECT * FROM info2 WHERE files=%s", (decoded_file,))
            file_details = cursor.fetchone()

            # Ensure all result sets are processed
            while cursor.nextset():
                pass

            # Construct the file path and read the CSV file
            file_path = os.path.join("C:/Users/Unical-012/Downloads/", decoded_file)
            if os.path.exists(file_path):
                with open(file_path, 'r') as csvfile:
                    reader = csv.reader(csvfile, delimiter=',')
                    column_names = next(reader)  # Assuming the first row contains column names

                    data = []
                    for row in reader:
                        data.append(row)

                    num_records = len(data)
                    if num_records > 0:
                        for i, col in enumerate(column_names):
                            col_data = [float(row[i]) for row in data if row[i].replace('.', '', 1).isdigit()]
                            if col_data:
                                periodicity = np.median(np.diff(col_data))
                                total_duration = col_data[-1] - col_data[0]
                                data_miss = (len(data) - len(col_data)) / len(data) * 100
                                jitter = np.median([abs(x - periodicity) for x in np.diff(col_data)])

                                details.append({
                                    'file_name': base_file_name,  # Use the extracted file name
                                    'parameter': col,
                                    'periodicity': periodicity,
                                    'total_duration': total_duration,
                                    'num_records': num_records,
                                    'data_miss': data_miss,
                                    'jitter': jitter,
                                })
    except Error as e:
        return HttpResponse(f"Error while connecting to MySQL: {e}")
    finally:
        if connection.is_connected():
            cursor.close()
            connection.close()
            print("MySQL connection is closed")

    context = {
        'details': details,
    }

    return render(request, 'quick.html', context)
