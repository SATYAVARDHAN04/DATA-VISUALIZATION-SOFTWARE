from django.urls import path
from . import views

urlpatterns = [
    path('quick_analysis/<str:file_name>/', views.quick_analysis_view, name='quick_analysis'),
]
