from django.shortcuts import render
import mysql.connector as sql
from mysql.connector import Error
import pandas as pd
import os
from django.http import JsonResponse

def state_transition_view(request):
    details = []
    time_params = []
    discrete_params = []

    try:
        connection = sql.connect(host="localhost", user="root", password="VARDHAN", database='login')
        if connection.is_connected():
            cursor = connection.cursor(dictionary=True)

            # Fetch the column names from info3
            cursor.execute("SHOW COLUMNS FROM info3")
            columns = cursor.fetchall()
            column_names = [column['Field'] for column in columns if column['Field'] != 'id']

            # Fetch the last 4 rows of info3 based on timestamp
            cursor.execute("SELECT * FROM login.info3 ORDER BY created_at DESC LIMIT 4")
            last_four_rows = cursor.fetchall()

            # Fetch the last inserted file from info2
            cursor.execute("SELECT files FROM login.info2 ORDER BY created_at DESC LIMIT 1")
            last_file_row = cursor.fetchone()
            last_file_name = last_file_row['files'] if last_file_row else None

            if last_four_rows and last_file_name:
                file_path = f"C:/Users/Unical-012/Downloads/{last_file_name}"

                if os.path.exists(file_path):
                    df = pd.read_csv(file_path)

                    for row in last_four_rows:
                        # Filter time parameters where time_param is 1
                        if row['time_param'] == 1:
                            time_params.append(row['column_name'])
                        
                        # Filter discrete parameters where parameter_type is 'discrete'
                        if row['parameter_type'] == 'discrete':
                            discrete_params.append(row['column_name'])

    except Error as e:
        return JsonResponse({'error': f"Error while connecting to MySQL: {e}"}, status=500)
    finally:
        if connection.is_connected():
            cursor.close()
            connection.close()

    context = {
        'time_params': time_params,
        'discrete_params': discrete_params,
    }

    return render(request, 'state_trans.html', context)

def state_transition_data(request):
    time_param = request.GET.get('time_param')
    discrete_param = request.GET.get('discrete_param')

    transitions = []

    try:
        connection = sql.connect(host="localhost", user="root", password="VARDHAN", database='login')
        if connection.is_connected():
            cursor = connection.cursor(dictionary=True)

            # Fetch the last inserted file from info2
            cursor.execute("SELECT files FROM login.info2 ORDER BY created_at DESC LIMIT 1")
            last_file_row = cursor.fetchone()
            last_file_name = last_file_row['files'] if last_file_row else None

            if last_file_name:
                file_path = f"C:/Users/Unical-012/Downloads/{last_file_name}"

                if os.path.exists(file_path):
                    df = pd.read_csv(file_path)

                    # Ensure the column names are correctly used
                    if time_param in df.columns and discrete_param in df.columns:
                        df_sorted = df.sort_values(by=[time_param])
                        prev_value = None
                        start_time = None

                        for index, row in df_sorted.iterrows():
                            current_value = row[discrete_param]
                            current_time = row[time_param]

                            if prev_value is None:
                                start_time = current_time
                                prev_value = current_value
                                continue

                            if current_value != prev_value:
                                transitions.append({
                                    'time_range': f"{start_time}-{current_time}",
                                    'discrete_value': prev_value,
                                })
                                start_time = current_time
                                prev_value = current_value

                        if start_time is not None and prev_value is not None:
                            transitions.append({
                                'time_range': f"{start_time}-{current_time}",
                                'discrete_value': prev_value,
                            })
                    else:
                        return JsonResponse({'error': f"Columns '{time_param}' or '{discrete_param}' not found in the dataset."}, status=400)

    except Error as e:
        return JsonResponse({'error': str(e)}, status=500)
    finally:
        if connection.is_connected():
            cursor.close()
            connection.close()

    return JsonResponse(transitions, safe=False)
