# state_transition/urls.py

from django.urls import path
from . import views

urlpatterns = [
    path('', views.state_transition_view, name='state_transition'),  # Matches /state_transition/
    path('data/', views.state_transition_data, name='state_transition_data'),  # Matches /state_transition/data/
]
